CREATE USER ‘insertupdate’@’localhost’ IDENTIFIED BY ‘enti’;
CREATE USER ‘select’@’localhost’ IDENTIFIED BY ‘enti’;
GRANT INSERT, UPDATE ON evilcorp.* TO ‘insertupdate’@’localhost’;
GRANT SELECT ON evilcorp.* TO ‘select’@’localhost’;

FLUSH PRIVILEGES;
