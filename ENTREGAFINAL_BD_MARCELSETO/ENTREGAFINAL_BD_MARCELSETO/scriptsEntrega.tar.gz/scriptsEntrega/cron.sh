#!/bin/bash

DIA=`echo $(date + %F)`

RUTA_COPIADIARIA="/root/backup/diario/"

rm $RUTA_COPIADIARIA*
mysqldump EvilCorp > ${RUTA_COPIADIARIA}copia.sql
tar -czvd ${RUTA_COPIADIARIA}copia_$DIA.tar.gz ${RUTA_COPIADIARIA}copia.sql
rm ${RUTA_COPIADIARIA}copia.sql