CREATE DATABASE EvilCorp;

DROP TABLE IF EXISTS users;

CREATE TABLE users (id_user INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT, username VARCHAR(32) NOT NULL, password VARCHAR(32) NOT NULL, name VARCHAR(16) NOT NULL, surname VARCHAR(32) NOT NULL, email VARCHAR(64) NOT NULL, contact_number VARCHAR(13) NOT NULL, register DATETIME NOT NULL, country VARCHAR(32) NOT NULL, gender CHAR(1) NOT NULL, birthdate DATE NOT NULL);

INSERT INTO users(username, password, name, surname, email, contact_number, register, country, gender, birthdate) 
VALUES ("root", "fb226127d0e2e623fb639a1b38bb88eb", "Hilon", "Musgo Muskiz", "hilonmusgoking@gmail.com", "+3465401345", now(), "Spain", 'N', "1971-06-28");